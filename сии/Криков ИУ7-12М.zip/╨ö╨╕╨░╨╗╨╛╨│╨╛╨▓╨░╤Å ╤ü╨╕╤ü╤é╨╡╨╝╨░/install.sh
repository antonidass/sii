python3.7 -m pip install --upgrade pip
python3.7 -m pip install pandas_ods_reader
python3.7 -m pip install regex
python3.7 -m pip install pymorphy2==0.9.1


