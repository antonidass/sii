def welcome():
	print('\nПопроси меня что-нибудь посоветовать!\n')

def bye():
	print('\nДо встречи!\n')

def more():
	print('\nМогу еще помочь?\n')

def not_found():
	print('\nНичего не понятно... Попробуй еще раз.')